package controller;

import dao.DoctorDAO;
import model.Doctor;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;

public class ChangePasswordServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String newPwd = request.getParameter("newPassword");
        String confirmPwd = request.getParameter("confirmPassword");
        Doctor doc = (Doctor) session.getAttribute("currentDoctor");

        if (doc != null) {
            // 1. Validate that the two new passwords match
            if (newPwd != null && newPwd.equals(confirmPwd)) {
                
                DoctorDAO dao = new DoctorDAO();
                boolean success = dao.updatePassword(doc.getId(), newPwd);

                if (success) {
                    session.invalidate(); 
                    
                    response.sendRedirect("doctorLogin.jsp?msg=Password Changed. Please Login with your NEW password.");
                } else {
                    session.setAttribute("errorMsg", "Database error: Could not update.");
                    response.sendRedirect("changePassword.jsp");
                }
            } else {
                session.setAttribute("errorMsg", "Passwords do not match!");
                response.sendRedirect("changePassword.jsp");
            }
        } else {
            response.sendRedirect("doctorLogin.jsp");
        }
    }
}